const { timingSafeEqual } = require('node:crypto');
const { openSession, closeSession, generateWav, problem } = require('../lib/browser');
const { validate } = require('../lib/validate');
const { toPcm, fit, mp3 } = require('../lib/audio');
let busy = false;
module.exports = async (req, res) => {
 res.setHeader('Cache-Control', 'no-store');
 if(req.method!=='POST'){res.setHeader('Allow','POST');return res.status(405).json({error:'Use POST.'});}
 let session,timer,ownsLock=false;
 try {
  const token=process.env.APP_TOKEN;
  if(!token||token.length<24)throw problem(503,'Set APP_TOKEN to a random secret of at least 24 characters.');
  const expected=Buffer.from('Bearer '+token),actual=Buffer.from(req.headers.authorization||'');
  if(actual.length!==expected.length||!timingSafeEqual(actual,expected))throw problem(401,'Invalid app token.');
  if(process.env.ACCEPT_SITE_TERMS!=='true')throw problem(503,'Read the source site’s terms and set ACCEPT_SITE_TERMS=true if you accept them.');
  let b=req.body;if(typeof b==='string'){try{b=JSON.parse(b);}catch{throw problem(400,'Invalid JSON.');}}
  const {cues,format,voice,output}=validate(b);
  if(busy)throw problem(429,'This instance is busy. Submit one request at a time.');
  busy=true;ownsLock=true;
  // The timer terminates a hung browser before Vercel's 300-second limit.
  const deadline=Date.now()+235000;
  session=await openSession();
  timer=setTimeout(()=>session.browser.close().catch(()=>{}),Math.max(1,deadline-Date.now()));
  const clips=[];let raw;
  for(const cue of cues){
   if(Date.now()>deadline-10000)throw problem(504,'Time budget reached. Use individual cue requests via the web interface.');
   raw=await generateWav(session,{text:cue.text,voice});
   if(output==='wav')break;
   let pcm=await toPcm(raw,'audio/wav');
   if(pcm.length>120*48000)throw problem(422,'Generated clip exceeds two minutes. Split the text.');
   if(cue.end!==undefined)pcm=await fit(pcm,cue.end-cue.start);
   clips.push({start:cue.start,pcm});
  }
  let result;
  if(output==='wav')result=raw;
  else {
   let pcm;
   if(format==='srt'){pcm=Buffer.alloc(Math.round(cues.at(-1).end*24000)*2);for(const c of clips)c.pcm.copy(pcm,Math.round(c.start*24000)*2);}
   else pcm=clips[0].pcm;
   result=output==='pcm'?pcm:await mp3(pcm);
  }
  if(result.length>4400000)throw problem(413,'Output exceeds the safe Vercel response size. Use smaller clips or MP3.');
  res.setHeader('Content-Type',output==='pcm'?'application/octet-stream':output==='wav'?'audio/wav':'audio/mpeg');
  res.setHeader('Content-Disposition',`attachment; filename="speech.${output}"`);
  res.setHeader('X-Audio-Sample-Rate','24000');
  return res.status(200).send(result);
 }catch(e){
  if(e.status===429)res.setHeader('Retry-After','60');
  return res.status(e.status||502).json({error:e.status?e.message:'Browser generation failed. The source may be unavailable, require verification, or have changed. Check deployment logs.',retryAutomatically:false});
 }finally{
  clearTimeout(timer);await closeSession(session);if(ownsLock)busy=false;
 }
};
