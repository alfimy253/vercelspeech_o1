# Playwright TTS · Vercel Node.js

Private proof of concept: POST text or short SRT, automate **freetexttospeech.net** with a real headless browser, download its WAV through the normal UI, and return MP3. Includes a webpage for longer timestamp-matched SRT files.

**No Gemini or ElevenLabs API key required. This is NOT unlimited TTS or an official integration.** Source-site allowances, privacy policy, availability, and terms still apply. Ask the operator about ongoing/public automation. No CAPTCHA solving, stealth, IP rotation, quota resets, or direct private API replay is implemented.

## Deploy on Vercel

1. Upload the contents of this `playwright` folder to a GitHub repository. Do not upload `node_modules`, `.env.local`, account cookies, or generated audio.
2. Import the repository at https://vercel.com/new.
3. Framework: **Other**. Node.js: **22.x**. Root directory: the directory containing this `package.json` (use `playwright` if your repo contains the parent folder).
4. Build command: `npm run build`. Output directory: `public`. `vercel.json` already specifies the function duration and bundled Chromium / FFmpeg assets.
5. Set these environment variables:

| Variable | Required value |
|---|---|
| `APP_TOKEN` | A random secret of at least 24 characters. Use 32 random bytes encoded as hex. |
| `ACCEPT_SITE_TERMS` | `true` **only after** reading and accepting https://freetexttospeech.net/terms and reviewing https://freetexttospeech.net/privacy |

Generate a token locally:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

6. Deploy. Open the website and enter your APP_TOKEN. Start with a short test.
7. Redeploy after changing environment variables.

No credit card or paid provider fallback is coded. Vercel and the source website have their own limits; verify that Vercel Hobby's personal/non-commercial restrictions fit your use. This project has not been deployed to your Vercel account. A successful sandbox test does not guarantee that the source will accept Vercel's IPs.

## POST plain text → MP3

```bash
curl --fail-with-body 'https://YOUR-PROJECT.vercel.app/api/tts' \
  -H 'Authorization: Bearer YOUR_APP_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{"input":"Hello, this is my narration.","voice":"af_nicole"}' \
  --output speech.mp3
```

On errors, the response is JSON, not audio. `--fail-with-body` returns a nonzero exit code, but may write that JSON into the output file; inspect the response before playing it.

## POST short SRT → timestamp-matched MP3

```bash
curl --fail-with-body 'https://YOUR-PROJECT.vercel.app/api/tts' \
  -H 'Authorization: Bearer YOUR_APP_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{"format":"srt","voice":"af_nicole","input":"1\n00:00:00,000 --> 00:00:05,000\nHello, welcome to my tutorial.\n\n2\n00:00:06,000 --> 00:00:11,000\nLet us get started."}' \
  --output speech.mp3
```

### Request fields

| Field | Meaning |
|---|---|
| `input` | Required script or SRT string |
| `format` | `text` (default) or `srt` |
| `voice` | Source-site voice ID, default `af_nicole` |
| `output` | `mp3` (default), `pcm`, or `wav` |
| `duration` | Optional time window for a text clip: >0 to 120 seconds |

Examples of voice IDs: `af_nicole`, `af_heart`, `af_bella`, `af_kore`, `am_adam`, `am_michael`, `bf_emma`, `bm_george`, `ff_siwis`. IDs are checked against the website's current voice list. The UI exposes a smaller starter selection.

PCM output is headerless mono signed 16-bit little-endian at 24,000 Hz. WAV output downloads the source WAV unchanged and only supports untimed plain text.

### Limits and timing

- Plain text: at most **5,000 characters**, matching the observed source-site input cap. For MP3/PCM, generated speech is capped at 2 minutes per clip; use much shorter text for predictable latency.
- Direct SRT POST: at most **8 cues / 2 minutes**. It can still time out if the source is slow. Direct POST has no persistent partial-result recovery.
- Webpage: at most **300 cues / 10 minutes**. It submits each cue separately, caches completed clips in the tab's memory, assembles the PCM timeline, and encodes MP3 locally using lamejs. It waits 10 seconds between fresh requests, but this is not a guarantee against rate limits.
- Keep the webpage open. Refreshing loses the in-memory clip cache. On quota errors, wait until the source permits more usage before resuming; daily/monthly limits are not fixed by an immediate retry.
- Short clips are padded with silence to fill each cue. Longer clips are sped up with FFmpeg's pitch-preserving `atempo`, up to **1.35×**. If they still cannot fit, the request fails rather than deliberately cutting speech. Processing/MP3 encoding can introduce small boundary differences; this is not phoneme-perfect dubbing.
- Overlapping or out-of-order cues are rejected. Shorten/edit a failing cue without introducing overlaps.
- Responses are limited to 4.4 MB, below Vercel's documented 4.5 MB payload cap. The browser deadline is approximately 235 seconds, under the configured 300-second function duration.

## How it works

```
POST /api/tts → check app token and input
             → @sparticuz/chromium + playwright-core
             → open the fixed source website
             → choose voice, enter text, accept terms (operator opt-in)
             → click Generate Speech
             → observe normal page request outcome
             → click Download WAV
             → FFmpeg decode / fit timing / MP3 encode
             → return audio
```

The browser and downloads are closed/deleted after each request. No client-supplied URL is accepted. The Google/ElevenLabs project from earlier is not modified.

### Quotas, sessions, and security

The live anonymous quota observed during inspection was 25,000 characters; the site's explanatory text had inconsistent allowance figures. **Do not treat that number as a permanent entitlement.** The site's current quota display and enforcement control usage.

Browser state is reused in memory on a warm Node.js instance. It is not durable across cold starts or shared between instances. There is no intentional reset-on-quota behavior, no retry loop, and no proxy rotation. If an upstream quota is exhausted, stop; do not redeploy or replace sessions to seek a fresh allowance.

Optional `TTS_STORAGE_STATE_BASE64` can supply **your own authorized** Playwright `storageState` JSON encoded as base64. This may contain account cookies: keep it in secret environment variables only, never in source control or client code. It is a snapshot, not durable session synchronization; logins may expire. Do not import anyone else's session.

`APP_TOKEN` and an in-process one-request lock are suitable for a small trusted personal deployment only. **The lock is not global across Vercel instances, and there is no durable rate-limit store.** Do not expose this as a public/free proxy. Before public or multi-user operation, obtain source-site approval and implement durable authentication, a shared queue, global concurrency control, session storage, and quota accounting. Do not assume the source's protections replace your own abuse controls.

Scripts are sent to freetexttospeech.net and its TTS provider. Marketing/email opt-in checkboxes are left unchecked. The function does not log script contents, download URLs, or cookies. Review your host's own logging settings separately.

## Run locally

Node 22 recommended. The bundled Chromium is intended for Linux/serverless use. For macOS/Windows set `CHROME_EXECUTABLE_PATH` to a compatible locally installed Chromium executable.

```bash
npm ci
cp .env.example .env.local
# Set APP_TOKEN; read the terms before setting ACCEPT_SITE_TERMS=true.
npm run build
npm run dev
```

Open http://localhost:3000. The included development server binds to `0.0.0.0`; production uses Vercel functions, not this server.

Optional CLI deployment:

```bash
npx vercel login
npx vercel link
npx vercel env add APP_TOKEN production
npx vercel env add ACCEPT_SITE_TERMS production
npx vercel --prod
```

## Tests and verification

```bash
npm test          # Offline tests; no website requests or quota consumed
npm run test:live # One real generation; requires ACCEPT_SITE_TERMS=true
```

Verified in this Linux workspace:
- **7 automated tests passed:** request validation, SRT parsing/overlap/length limits, timing padding and compression rejection, actual MP3 encoding, and authentication rejection before browser launch.
- **A live test with the bundled serverless Chromium succeeded:** 198,044-byte WAV downloaded via the website's normal download button and converted to a 33,452-byte MP3.
- The live test used a single short Nicole-voice sentence. Full 3–10 minute SRT processing, all voices, Vercel deployment, quota resets, and long-running reliability have **not** been verified.

The live test writes `smoke-test.mp3` locally; it is excluded from source control and the deliverable ZIP.

## Errors / troubleshooting

- **400**: invalid JSON, voice, SRT, format, or input length.
- **401**: APP_TOKEN missing or incorrect.
- **413**: audio exceeds response/download limit.
- **422**: clip too long or cannot fit its cue.
- **429**: local instance busy or source quota reached. `Retry-After: 60` is a conservative hint, NOT a promise that a monthly quota resets in a minute.
- **502**: source changed, generation/download failed, or authentication/verification required. Open the site manually to investigate. The app does not bypass verification.
- **503**: missing/invalid app configuration or terms not accepted.
- **504**: generation exceeds time budget; split into smaller requests.

If deployment cannot find Chromium or FFmpeg, confirm `vercel.json` was committed and the install ran on Vercel's Linux environment. Do not upload a local node_modules folder. If a downloaded MP3 does not play, check whether the response was actually a JSON error.

## Project files

- `api/tts.js`: authenticated Vercel endpoint
- `lib/browser.js`: source-site Playwright automation
- `lib/audio.js`: FFmpeg conversion and cue fitting
- `lib/srt.js`, `lib/validate.js`: input validation
- `public/`: SRT upload / generation / MP3 download interface
- `scripts/build.cjs`: bundle local browser dependencies
- `scripts/live-test.cjs`: opt-in real-site smoke test
- `test/`: offline tests
- `server.cjs`: local development server

Dependencies retain their respective licenses. Review Chromium, FFmpeg, lamejs, and the voice/model terms before redistribution or commercial use.
