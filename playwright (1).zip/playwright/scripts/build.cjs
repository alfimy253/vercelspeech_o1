const fs = require('node:fs');
fs.copyFileSync(require.resolve('lamejs/lame.min.js'), 'public/lame.min.js');
fs.copyFileSync('lib/srt.js', 'public/srt.js');
