// Explicit opt-in: makes ONE real, quota-consuming generation.
try { require('node:process').loadEnvFile('.env.local'); } catch {}
const fs=require('node:fs/promises');
const {openSession,closeSession,generateWav}=require('../lib/browser');
const {toPcm,mp3}=require('../lib/audio');
(async()=>{
 if(process.env.ACCEPT_SITE_TERMS!=='true')throw Error('Read the source terms; set ACCEPT_SITE_TERMS=true to run a real generation.');
 let session;
 try{
  session=await openSession();const wav=await generateWav(session,{text:'Hello. This is a short voice test.',voice:'af_nicole'});
  const audio=await mp3(await toPcm(wav,'audio/wav'));await fs.writeFile('smoke-test.mp3',audio);
  console.log(JSON.stringify({success:true,wavBytes:wav.length,mp3Bytes:audio.length,file:'smoke-test.mp3'}));
 }finally{await closeSession(session);}
})().catch(e=>{console.error(e.message);process.exitCode=1;});
