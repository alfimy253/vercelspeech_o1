const {test}=require('node:test'),assert=require('node:assert/strict');
const {validate}=require('../lib/validate');const {parseSrt}=require('../lib/srt');const {fit,mp3}=require('../lib/audio');const handler=require('../api/tts');
test('default voice and output',()=>{const v=validate({input:'Hello'});assert.equal(v.voice,'af_nicole');assert.equal(v.output,'mp3');});
test('rejects invalid and oversized input',()=>{for(const b of [{},{input:' '},{input:'x'.repeat(5001)},{input:'Hi',voice:'../../bad'},{input:'Hi',duration:-1},{input:'Hi',output:'exe'}])assert.throws(()=>validate(b));});
test('SRT parsing',()=>assert.deepEqual(parseSrt('1\r\n00:00:01,000 --> 00:00:03,000\r\n<b>Hello</b>'),[{start:1,end:3,text:'Hello'}]));
test('SRT rejects overlap',()=>assert.throws(()=>parseSrt('1\n00:00:00,000 --> 00:00:04,000\na\n\n2\n00:00:03,000 --> 00:00:05,000\nb')));
test('SRT direct length limit',()=>assert.throws(()=>validate({format:'srt',input:'1\n00:00:00,000 --> 00:02:01,000\nHello'}),/2 minutes/));
test('padding, compression bound and MP3 encoding',async()=>{assert.equal((await fit(Buffer.alloc(24000),1)).length,48000);await assert.rejects(fit(Buffer.alloc(96000),1));const b=await mp3(Buffer.alloc(48000));assert.equal(b.subarray(0,3).toString(),'ID3');});
test('authentication rejects before browser launches',async()=>{process.env.APP_TOKEN='test-secret-longer-than-24-characters';let code;const res={setHeader(){},status(c){code=c;return this;},json(){}};await handler({method:'POST',headers:{},body:{}},res);assert.equal(code,401);});
