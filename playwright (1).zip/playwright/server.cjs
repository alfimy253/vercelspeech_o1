// Local development server; Vercel invokes api/tts.js directly in production.
try { require('node:process').loadEnvFile('.env.local'); } catch {}
const http=require('node:http'),fs=require('node:fs/promises'),path=require('node:path');
const handler=require('./api/tts');
http.createServer(async(req,res)=>{
 res.status=c=>{res.statusCode=c;return res;};res.json=o=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify(o));};res.send=b=>res.end(b);
 if(req.url.split('?')[0]==='/api/tts'){
  let size=0,chunks=[];for await(const c of req){size+=c.length;if(size>100000){res.status(413).json({error:'Request too large.'});return;}chunks.push(c);}
  req.body=Buffer.concat(chunks).toString();await handler(req,res);return;
 }
 const files={'/':'index.html','/app.js':'app.js','/srt.js':'srt.js','/lame.min.js':'lame.min.js'};
 const name=files[req.url.split('?')[0]];if(!name){res.statusCode=404;res.end('Not found');return;}
 try{const b=await fs.readFile(path.join(__dirname,'public',name));res.setHeader('Content-Type',name.endsWith('.html')?'text/html; charset=utf-8':'application/javascript');res.end(b);}catch{res.statusCode=503;res.end('Run npm run build first.');}
}).listen(process.env.PORT||3000,'0.0.0.0',()=>console.log('App ready on port '+(process.env.PORT||3000)));
