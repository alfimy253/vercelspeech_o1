(function(root){
function parseSrt(input){
 const blocks=input.replace(/^\uFEFF/,'').replace(/\r/g,'').trim().split(/\n\s*\n/);
 const stamp='(\\d{2,}):([0-5]\\d):([0-5]\\d)[,.](\\d{3})';
 const re=new RegExp('^'+stamp+'\\s*-->\\s*'+stamp+'\\s*$');
 const seconds=(m,i)=>+m[i]*3600 + +m[i+1]*60 + +m[i+2] + +m[i+3]/1000;
 const cues=blocks.map((block,i)=>{
  const lines=block.split('\n'); if(/^\d+$/.test(lines[0].trim()))lines.shift();
  const m=(lines.shift()||'').trim().match(re); if(!m)throw Error('Invalid SRT timestamp in cue '+(i+1));
  const start=seconds(m,1),end=seconds(m,5),text=lines.join(' ').replace(/<[^>]*>/g,'').trim();
  if(!text||end<=start||end>600)throw Error('Cue '+(i+1)+': empty text, invalid duration, or timeline exceeds 10 minutes.');
  return {start,end,text};
 });
 if(cues.length>300)throw Error('Maximum 300 cues.');
 cues.forEach((c,i)=>{if(i&&c.start<cues[i-1].end)throw Error('Overlapping or out-of-order cues are not supported.');});
 return cues;
}
if(typeof module!=='undefined')module.exports={parseSrt};else root.parseSrt=parseSrt;
})(typeof window!=='undefined'?window:globalThis);
