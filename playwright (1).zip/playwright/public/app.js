const $=id=>document.getElementById(id);let cache=new Map(),url;
$('file').onchange=async()=>{const f=$('file').files[0];if(f){$('input').value=await f.text();$('format').value=f.name.endsWith('.srt')?'srt':'text';}};
$('reset').onclick=()=>{cache.clear();$('status').textContent='Saved clips cleared.';};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
$('generate').onclick=async()=>{
 const button=$('generate');button.disabled=true;$('reset').disabled=true;$('result').replaceChildren();
 try{
  const input=$('input').value,voice=$('voice').value,token=$('token').value,format=$('format').value;
  if(!token)throw Error('Enter your app access token first.');
  const cues=format==='srt'?parseSrt(input):[{text:input,start:0}];
  const clips=[];$('progress').max=cues.length;$('progress').value=0;
  for(let i=0;i<cues.length;i++){
   const cue=cues[i],body={format:'text',input:cue.text,voice,output:'pcm',...(cue.end!==undefined?{duration:cue.end-cue.start}:{})};
   const key=JSON.stringify(body);let clip=cache.get(key);
   if(!clip){
    $('status').textContent=`Generating cue ${i+1} of ${cues.length}…`;
    const r=await fetch('/api/tts',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(body)});
    if(!r.ok){const e=await r.json().catch(()=>({error:`HTTP ${r.status}`}));throw Error(`Cue ${i+1}: ${e.error}\nCompleted clips are retained. Wait if quota-limited, then click Resume.`);}
    const raw=await r.arrayBuffer(),view=new DataView(raw);clip=new Int16Array(raw.byteLength/2);
    for(let j=0;j<clip.length;j++)clip[j]=view.getInt16(j*2,true);
    cache.set(key,clip);
    // Conservative spacing, not a guarantee of staying within your project's quota.
    if(i<cues.length-1){$('status').textContent=`Cue ${i+1} saved. Waiting 10 seconds before the next request…`;await wait(10000);}
   }
   clips.push(clip);$('progress').value=i+1;
  }
  $('status').textContent='Assembling timeline and encoding MP3 locally…';await wait(30);
  const length=format==='srt'?Math.round(cues.at(-1).end*24000):clips[0].length;
  const timeline=new Int16Array(length);
  clips.forEach((clip,i)=>{const offset=Math.round(cues[i].start*24000);timeline.set(clip.subarray(0,length-offset),offset);});
  const encoder=new lamejs.Mp3Encoder(1,24000,64),chunks=[];
  for(let i=0;i<timeline.length;i+=1152){const chunk=encoder.encodeBuffer(timeline.subarray(i,i+1152));if(chunk.length)chunks.push(new Uint8Array(chunk));if(i%(1152*200)===0)await wait(0);}
  const tail=encoder.flush();if(tail.length)chunks.push(new Uint8Array(tail));
  if(url)URL.revokeObjectURL(url);url=URL.createObjectURL(new Blob(chunks,{type:'audio/mpeg'}));
  const audio=document.createElement('audio');audio.controls=true;audio.src=url;
  const link=document.createElement('a');link.className='download';link.href=url;link.download='speech.mp3';link.textContent='Download MP3';$('result').append(audio,link);
  $('status').textContent=`Done · ${(length/24000).toFixed(1)} seconds · ${cues.length} cue(s).`;button.textContent='Generate MP3';
 }catch(e){$('status').textContent=e.message;button.textContent='Resume / try again';}
 finally{button.disabled=false;$('reset').disabled=false;}
};
